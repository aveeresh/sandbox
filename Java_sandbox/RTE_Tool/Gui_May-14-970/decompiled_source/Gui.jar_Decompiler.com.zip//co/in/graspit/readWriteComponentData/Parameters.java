package co.in.graspit.readWriteComponentData;

public enum Parameters {
   Deleted;

   public String getParaName() {
      String paraName = "Deleted";
      return paraName;
   }
}
