package co.in.graspit.readWriteComponentData;

public class AddDataToXml {
   AddDataToXml() {
   }

   void addComponent(String componentName) {
   }

   void addPortToComponent(String componentName, String[][] portData) {
   }
}
