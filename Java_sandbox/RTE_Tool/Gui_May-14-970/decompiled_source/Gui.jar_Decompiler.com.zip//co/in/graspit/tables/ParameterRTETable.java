package co.in.graspit.tables;

import javax.swing.JTable;

public class ParameterRTETable extends JTable {
}
