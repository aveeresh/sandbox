#ifndef UART_H
#define UART_H

#include "LPC17xx.h"
#include <stdint.h>
#include <stdbool.h>

// Function Prototypes
void UART_Init(void);  // Initialize all UARTs with default settings
void UART_SetConfig(uint8_t uart_num, uint32_t baudrate, uint8_t databits, uint8_t stopbits, uint8_t parity);
void UART_SendByte(uint8_t uartx, uint8_t data);
void UART_SendData(uint8_t uartx, const uint8_t *data, uint16_t length);
uint8_t UART_ReceiveByte(uint8_t uartx);
void UART_ReceiveData(uint8_t uartx, uint8_t *buffer, uint16_t max_length);
bool UART_IsTransmitReady(uint8_t uartx);
bool UART_IsReceiveReady(uint8_t uartx);

#endif
