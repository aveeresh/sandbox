#include<lpc17xx.h>
#include<stdio.h>
#include "ADC_driver.h"
#include "lcd.h"


int main(){
		uint16_t adc_result;
		char result[6];
		unsigned char msg1[]={"Temperature = "};
		unsigned char msg2[]={"C"};
		uint16_t integer,decimal;
		SystemInit();
		SystemCoreClockUpdate();
		ADC_Init(10); 
		lcd_init();
		while(1){
				adc_result=ADC_ReadValue(0); //Using channel 0
				integer=adc_result/10;
				decimal=adc_result%10;
				temp1 = 0x80;			
				lcd_com();
				delay_lcd(650000);
				lcd_puts(msg1);
				sprintf(result,"%x.%x",integer,decimal);
				temp1 = 0xC0;			
				lcd_com();
				delay_lcd(650000);
				lcd_puts((unsigned char*)result);
				temp1 = 0xC5;			
				lcd_com();
				delay_lcd(650000);
				lcd_puts(msg2);
				ADC_Delay();
			
		}
}	
