#include "CAN_Driver.h"
#include "Can_Regs.h"

#define MEGA(x) (x * 1000000)
#define KILO(x) (x * 1000)

static Can_GeneralRegs_t *CanRegs[] = {(Can_GeneralRegs_t*)0x40044000, (Can_GeneralRegs_t*)0x40048000};

void CAN_Init(CanIdx_t CanIdx) 
{
	
}

void CAN_Set_BaudRate(CanIdx_t CanIdx, uint8 BRP, uint8 SJW, uint8 TSEG1, uint8 TSEG2) 
{
		#if 0
		CanRegs[CanIdx]->MOD.R  |= 0x01; // Enter Reset Mode
		temp = &(CanRegs[CanIdx-1]->BTR.R);
    CanRegs[CanIdx]->BTR.R = btr_value; // Set BTR register
		//CanRegs[CanIdx-1]->MOD.R |= (0x01<<2); //enable self test mode

    CanRegs[CanIdx]->MOD.R &= (~(0x01) & 0xBF); // Exit Reset Mode
		#else
		CanRegs[CanIdx]->MOD.B.RM = 1;
		CanRegs[CanIdx]->BTR.B.SJW = SJW;
		CanRegs[CanIdx]->BTR.B.BRP = BRP;
		CanRegs[CanIdx]->BTR.B.TSEG1 = TSEG1;
		CanRegs[CanIdx]->BTR.B.TSEG2 = TSEG2;
		CanRegs[CanIdx]->MOD.B.RM = 0;
		#endif
}

void CAN_Transmit(CanIdx_t CanIdx, CanMsg_t TxMsg) 
{
		//while (!(CAN1->SR & (1 << 2))); // Wait until TX buffer is empty
		CanRegs[CanIdx]->TFI1.B.DLC    = TxMsg.len;
		CanRegs[CanIdx]->TID1.StdId.Id = TxMsg.id.StdId.value;
		CanRegs[CanIdx]->TDA1.R        = TxMsg.data[0]; // Load first 4 bytes
		CanRegs[CanIdx]->TDB1.R        = TxMsg.data[4]; // Load next 4 bytes
		CanRegs[CanIdx]->CMR.R         = (1 << 5) | (1 << 0); // Request transmission
		//while(!((CAN1->GSR)&(0x01<<3)));
}

